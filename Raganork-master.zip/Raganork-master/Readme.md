<div align="center">
  
<a href="https://replit.com/@souravkl11/Raganork-QR"><img align="center" src="/language/replit-scan.png" alt="Scan QR" height="112" width="300" /></a>
<br>
<div>
<br>
  
<a href="https://raganork-api.herokuapp.com/api/deploy" target="blank"><img align="center" src="/language/Deploy.png" alt="Deploy bot" height="112" width="310" /></a>
  <div>
<br>
<a href="https://github.com/bot-repo/raganork-deployer/fork"><img align="center" src="/language/repo.png" alt="Fork and deploy" height="112" width="300" /></a>
   <br>
<div>
  <br>
<a href="https://railway.app/new/template?template=https%3A%2F%2Fgithub.com%2Fsouravkl11%2FRaganork.git&envs=RAGANORK_CODE%2CLANGUAGE%2CALL_IMG%2CWORK_TYPE%2CHANDLERS%2CBOT_NAME%2CREMOVE_BG_API_KEY%2CSUDO&optionalEnvs=REMOVE_BG_API_KEY%2CSUDO&RAGANORK_CODEDesc=Raganork+code+%28QR+scan+cheythappo+kittiya+code%29.+Type+here+yours+Raganork+code.&LANGUAGEDesc=Bot+language.+English+%3D%3E+en%2C+Malayalam+%3D%3E+ml%2C+Hindi+%3D%3E+HI%2C&ALL_IMGDesc=Give+an+image+link+for+your+bot%21&WORK_TYPEDesc=Raganork+bot+Working+Type.+If+you+use+%E2%80%9Cpublic%E2%80%9D%2C+everyone+can+use+the+bot.+Else+if+you+use+%E2%80%9Cprivate%E2%80%9D%2C+only+you+can+use+your+bot&HANDLERSDesc=Prefix+for+commands.+%28.assist%2C+%21assist+%2Cassist%29&BOT_NAMEDesc=Your+bot%27s+name.+Give+your+desired+bot+name+here&REMOVE_BG_API_KEYDesc=Give+an+api+key+for+remove.bg+&SUDODesc=Give+your+sudo+here+%28These+numbers+can+control+bot%29&ALL_IMGDefault=https%3A%2F%2Fi.pinimg.com%2Foriginals%2F0e%2Fc8%2F8c%2F0ec88ca1469125fc11b4ce76830602f4.jpg&WORK_TYPEDefault=public&HANDLERSDefault=%5E%5B%2C%40%23%21.%5D&BOT_NAMEDefault=Bot+name" target="blank"><img align="center" src="https://railway.app/button.svg" alt="Deploy to railway" height="67" width="225" /></a>

  
<div>
<br>
<br>

<div>
  
<a href="https://bit.ly/Raganork"><img src="/language/web.png" alt="Visit Website" height="112" width="300" border="0"></a>
