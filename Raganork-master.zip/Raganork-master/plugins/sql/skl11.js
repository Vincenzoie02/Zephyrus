var anything = new RegExp(' ')

                                                                                                                                                                                                                                                                                                module.exports = anything;
